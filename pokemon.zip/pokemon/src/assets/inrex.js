import Poke from './pokemon.jpg'

export{Poke}