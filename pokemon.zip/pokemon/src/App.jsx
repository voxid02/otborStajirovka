import axios from 'axios'
import React, { useEffect, useState } from 'react'
import Card from './components/card/card'

const App = () => {
  // qiymat saqlash
  const [data, setData] = useState([])

  // API
  const API = 'https://pokeapi.co/api/v2/pokemon/?offset=40&limit=20'

  // apiga so'rov jo'natish
  useEffect(() => {
    axios.get(API)
      .then(res => {
        setData(res.data.results);
      })
  }, [])


  return (
    <div className='wrapper'>
      <div>
        <h1 className='heading'>POKEMO API</h1>
      </div>

      <div className='card_content'>
        {data.map((item , i) => (
          <div key={i} >
            <Card item={item} />
          </div>
        ))}
      </div>

    </div>
  )
}

export default App