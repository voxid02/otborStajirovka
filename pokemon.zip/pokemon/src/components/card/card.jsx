import React from 'react'
import { Poke } from '../../assets/inrex';

const Card = ({item}) => {
    console.log(item);
  return (
    <div className='card'>
        {/* rasim uchun */}
        <div>
            <img width={'100%'} src={Poke} alt="" />
        </div>
        
        {/* title uchun */}
        <div>
            <h1>{item.name}</h1>
        </div>
    </div>
  )
}

export default Card